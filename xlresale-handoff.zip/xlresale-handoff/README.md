# XLResale — Claude Code handoff

Everything Claude Code needs to build the XLResale website. Unzip this into your repo
root; the folders are already in the right places.

## What's here

| File | What it is |
|---|---|
| `CLAUDE.md` | **Start here.** The build brief — product, stack, scope, phases, specs. Claude Code reads this first. |
| `DESIGN.md` | The design system — palette, type, mascot, hero, components. The source of truth for all UI. |
| `MAPS-COST-CONTROLS.md` | How to use Google Maps without surprise bills (matrix caching, one map instance, billing cap). |
| `schema.sql` | The complete Supabase database migration. Paste into the Supabase SQL Editor and run. |
| `reference/design-reference.html` | Visual prototype of the product UI (map, route planner, host Go Live). **Reference only — don't port.** |
| `reference/hero-frame.html` | The built landing hero, over the real mascot render. Rebuild the hero to match it. |
| `reference/hero.png` | Copy of the hero image so `hero-frame.html` renders standalone. |
| `public/mascot/hero.png` | The production hero illustration, at the path the app expects. |

## How to start

1. Unzip into your repo root and commit.
2. Have accounts ready: Supabase, Stripe, Google Maps Platform, Vercel (Resend + Anthropic
   are v2).
3. Open the repo in Claude Code and paste the kickoff prompt from `CLAUDE.md` §16.

## Assets still to add (drop in as you build)

- `public/mascot/hero-mobile.png` — the tall 9:16 hero crop for phones.
- `public/mascot/shrug.png`, `404.png`, `celebrate.png`, `pin.png`, `peek.png` — the mascot
  poses for empty / error / success / loading states. Naming and usage are in
  `DESIGN.md` → Mascot.

## Notes

- The `reference/*.html` files may say "Haul" (the old working name). The product is
  **XLResale**; database table names are generic and unaffected.
- The mascot doesn't have a name yet — picking one will sharpen all the microcopy.
